/**
 * Contains shared, general-purpose helper classes and annotations.
 */
package javax.enterprise.util;