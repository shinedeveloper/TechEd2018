package antlr.debug;

public interface SemanticPredicateListener extends ListenerBase {


	public void semanticPredicateEvaluated(SemanticPredicateEvent e);
}
