/**
 * The internals of archive scanning support
 */
package org.hibernate.jpa.boot.archive.internal;
