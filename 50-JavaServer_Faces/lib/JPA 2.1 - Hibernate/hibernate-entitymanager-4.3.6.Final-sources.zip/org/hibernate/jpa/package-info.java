/**
 * Defines Hibernate implementation of Java Persistence specification.
 */
package org.hibernate.jpa;
