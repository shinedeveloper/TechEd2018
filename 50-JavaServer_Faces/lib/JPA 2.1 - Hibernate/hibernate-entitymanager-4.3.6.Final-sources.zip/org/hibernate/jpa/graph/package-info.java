/**
 * Definition of the Hibernate support for the JPA {@link javax.persistence.EntityGraph} feature-set
 * introduced in JPA 2.1
 */
package org.hibernate.jpa.graph;
